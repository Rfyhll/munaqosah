#!/usr/bin/env python3
"""Generate a TEST .docx with different names to verify parsing works."""

from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT


def main():
    doc = Document()
    doc.add_heading("Daftar Santri Test MonaQosah", level=1).alignment = (
        WD_ALIGN_PARAGRAPH.CENTER
    )

    rows = [
        ("No", "Nama", "Kelas", "Kitab", "Halaman / Bab"),
        ("1", "Muhammad Yusuf Asy'ari", "Kelas 3 Tsanawiyyah", "Fathul Qarib", "Hal. 12 - Bab Wudhu"),
        ("2", "Abdurrahman bin Auf", "Kelas 4 Tsanawiyyah", "Bulughul Maram", "Hadits 25 - Bab Thaharah"),
        ("3", "Salman Al-Farisi", "Kelas 5 Tsanawiyyah", "Safinatun Najah", "Hal. 45 - Bab Shalat"),
        ("4", "Ali bin Abi Thalib", "Kelas 6 Tsanawiyyah", "Riyadhus Shalihin", "Bab 5 - Adab"),
        ("5", "Hasan Al-Bashri", "Kelas 2 Tsanawiyyah", "Fathul Qarib", "Hal. 78 - Bab Jinayah"),
    ]
    table = doc.add_table(rows=len(rows), cols=5)
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    widths = [Cm(1), Cm(5), Cm(4), Cm(4), Cm(5)]
    for i, row in enumerate(table.rows):
        for j, cell in enumerate(row.cells):
            cell.text = rows[i][j]
            cell.width = widths[j]
            if i == 0:
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for r in p.runs:
                        r.bold = True
                        r.font.color.rgb = RGBColor(0xF7, 0xE0, 0x7A)

    out_path = "/tmp/test-monaqosah.docx"
    doc.save(out_path)
    print(f"Test file saved: {out_path}")


if __name__ == "__main__":
    main()
