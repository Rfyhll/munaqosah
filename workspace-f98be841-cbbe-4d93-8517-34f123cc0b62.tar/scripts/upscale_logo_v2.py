#!/usr/bin/env python3
"""Upscale and sharpen the new clearer Bahtra logo (OIP (2).jpg)."""

from PIL import Image, ImageFilter, ImageEnhance
import os

def main():
    src = "/home/z/my-project/upload/OIP (2).jpg"
    dst_dir = "/home/z/my-project/public"

    img = Image.open(src)
    print(f"Original size: {img.size}, mode: {img.mode}")

    # Convert to RGBA
    if img.mode != "RGBA":
        img = img.convert("RGBA")

    w, h = img.size
    # Upscale to at least 800x800 for HD display
    target_size = 1000
    if max(w, h) < target_size:
        scale = target_size / max(w, h)
        new_size = (int(w * scale), int(h * scale))
        img = img.resize(new_size, Image.LANCZOS)
        print(f"Upscaled to: {img.size}")

    # Sharpen multiple times
    img = img.filter(ImageFilter.UnsharpMask(radius=2, percent=180, threshold=2))
    img = img.filter(ImageFilter.UnsharpMask(radius=1, percent=120, threshold=3))

    # Enhance
    img = ImageEnhance.Contrast(img).enhance(1.12)
    img = ImageEnhance.Color(img).enhance(1.08)
    img = ImageEnhance.Sharpness(img).enhance(1.3)

    # Save HD PNG
    dst_png = os.path.join(dst_dir, "bahtra-logo-hd.png")
    img.save(dst_png, "PNG", optimize=True)
    print(f"Saved: {dst_png} ({img.size})")

    # Save HD WebP
    dst_webp = os.path.join(dst_dir, "bahtra-logo-hd.webp")
    img.save(dst_webp, "WEBP", quality=95)
    print(f"Saved: {dst_webp}")

if __name__ == "__main__":
    main()
