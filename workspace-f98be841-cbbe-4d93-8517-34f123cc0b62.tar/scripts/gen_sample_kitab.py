#!/usr/bin/env python3
"""Generate a sample .docx with actual kitab-style content for projector testing."""

from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def set_rtl(paragraph):
    pPr = paragraph._p.get_or_add_pPr()
    bidi = OxmlElement("w:bidi")
    bidi.set(qn("w:val"), "1")
    pPr.append(bidi)


def set_run_arabic_font(run):
    rPr = run._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:cs"), "Traditional Arabic")
    rFonts.set(qn("w:ascii"), "Traditional Arabic")
    rFonts.set(qn("w:hAnsi"), "Traditional Arabic")


def main():
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(12)

    # Title
    title = doc.add_heading("Kitab Fathul Qarib", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = sub.add_run("Bab Thaharah - Halaman 24")
    run.italic = True
    run.font.size = Pt(14)
    run.font.color.rgb = RGBColor(0x9C, 0x7A, 0x1E)

    doc.add_paragraph()

    # Arabic matan
    ar_heading = doc.add_heading("المتن", level=2)
    ar_heading.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    ar_p = doc.add_paragraph()
    ar_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_rtl(ar_p)
    ar_run = ar_p.add_run(
        "الطَّهَارَةُ رُكْنٌ مِنْ أَرْكَانِ الْإِسْلَامِ، لَا يَصِحُّ الصَّلَاةُ إِلَّا بِهَا. "
        "وَهِيَ رَفْعُ الْحَدَثِ وَإِزَالَةُ الْخَبَثِ."
    )
    ar_run.font.size = Pt(20)
    ar_run.bold = True
    set_run_arabic_font(ar_run)

    doc.add_paragraph()

    # Terjemahan
    id_heading = doc.add_heading("Terjemahan", level=2)
    id_p = doc.add_paragraph(
        "Thaharah (bersuci) adalah rukun dari rukun-rukun Islam, tidak sah shalat "
        "kecuali dengannya. Yaitu mengangkat hadats dan menghilangkan khabats."
    )
    id_p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    doc.add_paragraph()

    # Syarah
    doc.add_heading("Syarah (Penjelasan)", level=2)
    doc.add_paragraph(
        "Thaharah merupakan syarat sah shalat sebagaimana disebutkan dalam hadits "
        "Nabi SAW: 'La yaqbalullahu shalata ahadikum idha hadatsa hatta yatawadda'a.' "
        "Artinya: Allah tidak menerima shalat seseorang di antara kalian jika berhadats "
        "hingga ia berwudhu."
    )

    doc.add_paragraph(
        "Thaharah terbagi menjadi dua jenis:"
    )

    # List
    doc.add_paragraph(
        "Mengangkat hadats - yaitu dengan berwudhu, mandi, atau tayamum.",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Menghilangkan khabats - yaitu membersihkan najis dari badan, pakaian, atau tempat.",
        style="List Bullet",
    )

    doc.add_paragraph()

    # Tabel ringkasan
    doc.add_heading("Ringkasan", level=2)
    table = doc.add_table(rows=4, cols=2)
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    cells_data = [
        ("Pembahasan", "Keterangan"),
        ("Kitab", "Fathul Qarib"),
        ("Bab", "Thaharah"),
        ("Halaman", "24"),
    ]
    for i, (k, v) in enumerate(cells_data):
        row = table.rows[i]
        row.cells[0].text = k
        row.cells[1].text = v
        if i == 0:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        r.bold = True

    doc.add_paragraph()

    # Catatan akhir
    note = doc.add_paragraph()
    note_run = note.add_run(
        "Catatan: Santri wajib membaca dengan tajwid yang baik dan tartil. "
        "Perhatikan makhraj dan sifat huruf ketika membaca teks Arab."
    )
    note_run.italic = True
    note_run.font.size = Pt(11)
    note_run.font.color.rgb = RGBColor(0x9C, 0x7A, 0x1E)

    out_path = "/tmp/sample-kitab.docx"
    doc.save(out_path)
    print(f"Sample saved: {out_path}")


if __name__ == "__main__":
    main()
