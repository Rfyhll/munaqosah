#!/usr/bin/env python3
"""Convert the Bahtra vector SVG to high-resolution PNG for use as logo."""

import subprocess
import os

def main():
    svg = "/home/z/my-project/public/bahtra-logo-vector.svg"
    png = "/home/z/my-project/public/bahtra-logo-hd.png"

    # Use rsvg-convert or Inkscape or resvg for high-quality SVG → PNG
    # Try resvg first (fast, high quality), fall back to rsvg-convert, then Inkscape
    cmds = [
        ["resvg", "-w", "1000", "-h", "1000", svg, png],
        ["rsvg-convert", "-w", "1000", "-h", "1000", "-o", png, svg],
        ["inkscape", "--export-type=png", "--export-filename=" + png,
         "--export-width=1000", "--export-height=1000", svg],
    ]

    for cmd in cmds:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0 and os.path.exists(png):
                print(f"Converted with: {' '.join(cmd[:1])}")
                print(f"Output: {png} ({os.path.getsize(png)} bytes)")
                return
        except FileNotFoundError:
            continue
        except subprocess.TimeoutExpired:
            continue

    # Fallback: use cairosvg (Python)
    try:
        import cairosvg
        cairosvg.svg2png(url=svg, write_to=png, output_width=1000, output_height=1000)
        print(f"Converted with cairosvg")
        print(f"Output: {png} ({os.path.getsize(png)} bytes)")
        return
    except Exception as e:
        print(f"cairosvg failed: {e}")

    print("ERROR: No SVG converter available. Install resvg/rsvg-convert/inkscape/cairosvg")

if __name__ == "__main__":
    main()
