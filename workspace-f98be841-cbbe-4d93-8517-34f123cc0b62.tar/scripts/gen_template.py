#!/usr/bin/env python3
"""Generate sample .docx template for MonaQosah operator upload.

The website parses tables in the .docx file. Each row becomes one santri.
Columns expected: No, Nama, Kelas, Kitab, Halaman/Bab.
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def set_cell_bg(cell, color_hex: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    tc_pr.append(shd)


def main():
    doc = Document()

    # Set default font
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # Title
    title = doc.add_heading("Daftar Santri MonaQosah", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = sub.add_run("Pondok Pesantren Bahtra")
    run.italic = True
    run.font.size = Pt(12)
    run.font.color.rgb = RGBColor(0x9C, 0x7A, 0x1E)

    # Instructions
    info = doc.add_paragraph()
    info_run = info.add_run(
        "Petunjuk: Edit tabel di bawah ini dengan nama santri yang akan diuji. "
        "Kolom yang wajib: Nama, Kelas, Kitab, Halaman/Bab. "
        "Simpan file sebagai .docx lalu upload ke website MonaQosah."
    )
    info_run.font.size = Pt(10)
    info_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    doc.add_paragraph()

    # Build the table
    rows_data = [
        ("No", "Nama", "Kelas", "Kitab", "Halaman / Bab"),
        ("1", "Ahmad Faiz Abdullah", "Kelas 5 Tsanawiyyah", "Fathul Qarib", "Hal. 24 - Bab Thaharah"),
        ("2", "Bilal Ramadhan Putra", "Kelas 6 Tsanawiyyah", "Fathul Qarib", "Hal. 58 - Bab Shalat"),
        ("3", "Umar Faruq Hidayat", "Kelas 4 Tsanawiyyah", "Fathul Qarib", "Hal. 102 - Bab Zakat"),
        ("4", "Zaid Abdul Karim", "Kelas 5 Tsanawiyyah", "Fathul Qarib", "Hal. 140 - Bab Puasa"),
        ("5", "Khalid Rahman Saleh", "Kelas 6 Tsanawiyyah", "Fathul Qarib", "Hal. 175 - Bab Haji"),
    ]

    table = doc.add_table(rows=len(rows_data), cols=5)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Light Grid Accent 1"

    # Set column widths
    widths = [Cm(1), Cm(5), Cm(4), Cm(4), Cm(5)]
    for i, row in enumerate(table.rows):
        for j, cell in enumerate(row.cells):
            cell.text = rows_data[i][j]
            cell.width = widths[j]
            # Header row styling
            if i == 0:
                set_cell_bg(cell, "0F4D3A")
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for r in p.runs:
                        r.bold = True
                        r.font.color.rgb = RGBColor(0xF7, 0xE0, 0x7A)
                        r.font.size = Pt(11)
            else:
                for p in cell.paragraphs:
                    for r in p.runs:
                        r.font.size = Pt(11)
                    if j == 0:
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph()
    note = doc.add_paragraph()
    note_run = note.add_run(
        "Catatan: Anda bisa menambah/mengurangi baris sesuai jumlah santri. "
        "Pastikan kolom Nama, Kelas, Kitab, dan Halaman terisi."
    )
    note_run.italic = True
    note_run.font.size = Pt(9)
    note_run.font.color.rgb = RGBColor(0x9C, 0x7A, 0x1E)

    out_path = "/home/z/my-project/public/template-monaqosah.docx"
    doc.save(out_path)
    print(f"Template saved to: {out_path}")


if __name__ == "__main__":
    main()
