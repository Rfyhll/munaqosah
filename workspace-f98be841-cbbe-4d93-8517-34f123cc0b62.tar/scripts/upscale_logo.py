#!/usr/bin/env python3
"""Upscale and sharpen the Bahtra logo for HD display."""

from PIL import Image, ImageFilter, ImageEnhance
import os

def main():
    src = "/home/z/my-project/upload/0de5a6a389dd627bf8b6c989470374b1.webp"
    dst_dir = "/home/z/my-project/public"

    img = Image.open(src)
    print(f"Original size: {img.size}, mode: {img.mode}")

    # Convert to RGBA for proper compositing
    if img.mode != "RGBA":
        img = img.convert("RGBA")

    # Upscale 16x with LANCZOS (high quality) - original is only 70x70
    w, h = img.size
    new_size = (w * 16, h * 16)
    img_up = img.resize(new_size, Image.LANCZOS)

    # Apply sharpening filter multiple times for crisp edges
    img_sharp = img_up.filter(ImageFilter.UnsharpMask(radius=3, percent=200, threshold=2))
    img_sharp = img_sharp.filter(ImageFilter.UnsharpMask(radius=1, percent=150, threshold=3))

    # Enhance contrast and color
    enhancer = ImageEnhance.Contrast(img_sharp)
    img_final = enhancer.enhance(1.15)
    color_enhancer = ImageEnhance.Color(img_final)
    img_final = color_enhancer.enhance(1.1)

    # Save as PNG (lossless) for max quality
    dst_png = os.path.join(dst_dir, "bahtra-logo-hd.png")
    img_final.save(dst_png, "PNG", optimize=True)
    print(f"Saved HD PNG: {dst_png} ({img_final.size})")

    # Also save a WebP version (high quality) as fallback
    dst_webp = os.path.join(dst_dir, "bahtra-logo-hd.webp")
    img_final.save(dst_webp, "WEBP", quality=95, lossless=True)
    print(f"Saved HD WebP: {dst_webp} ({img_final.size})")

if __name__ == "__main__":
    main()
